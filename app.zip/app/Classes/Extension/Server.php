<?php

namespace App\Classes\Extension;

/**
 * Class Server
 */
class Server extends Extension {}
