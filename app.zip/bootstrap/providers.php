<?php

return [
    App\Providers\AppServiceProvider::class,
    App\Providers\SettingsProvider::class,
    App\Providers\Filament\AdminPanelProvider::class,
    App\Providers\CustomPagesServiceProvider::class,
    \SocialiteProviders\Manager\ServiceProvider::class,
];
